﻿using System.Collections;
using System;

namespace PlaneQueing
{

    public class Airport
    {
        public ArrayList SmallRunway { get; set; }
        public ArrayList LargeRunway { get; set; }
        public String AirportName { get; set; }


        /*The airport class consist of two arraylists of plane objects. These will act as our queue*/
        /*I chose arraylist since we need a way to store the plane objects and modify the schedule if needed*/
        public Airport()
        {
            SmallRunway = new ArrayList();
            LargeRunway = new ArrayList();
        }
        //incase the airport has a name or multiple airport objects
        public Airport(string name): this()
        {
            AirportName = name;
        }

        /* Helper method for AddToList method*/
        private int FindCargo(int rw, int index)
        {
            ArrayList search;

            if (rw == 1) { search = SmallRunway; } else { search = LargeRunway; }
            foreach (Plane p in search)
            {
                if (p.Type.Equals("passenger"))
                {
                    index++;
                }
            }
            return index;
        }

        /* Helper method for AddToSchedule method*/
        private void AddToList(int runway, Plane plane)
        {
            int index = 0;
            if (runway == 1)
            {                
                index = FindCargo(1, index);                
                SmallRunway.Insert(index, plane);
            }
            else
            {
                index = FindCargo(2, index);
                LargeRunway.Insert(index, plane);
            }
            
        }

        /* Input: Plane object 
         * Depending on the size of the plane, the method, puts the plane in the respective runway.
         * If the type is cargo then it is added to the schedule without modifying the runway list and 
         * if it is a passenger plane then the method looks for the correct position in the list to 
         * add since passenger planes have priority over cargo planes */
        public void AddToSchedule(Plane plane)
        {
            if (plane.Size.Equals("small"))
            {
                if(SmallRunway.Count == 0 || plane.Type.Equals("cargo"))
                {
                    SmallRunway.Add(plane);
                }
                else
                {
                    AddToList(1, plane);
                }
            }
            else
            {
                if (LargeRunway.Count == 0 || plane.Type.Equals("cargo"))
                {
                    LargeRunway.Add(plane);
                }
                else
                {
                    AddToList(2, plane);
                }
            }
        }

        public Plane NextPlane(string runwaySize)
        {
            Plane nxtPlane;
            if (runwaySize.Equals("large"))
            {
                nxtPlane = (Plane)LargeRunway[0];
                LargeRunway.Remove(nxtPlane);
            }
            else if(runwaySize.Equals("small")
            {
                nxtPlane = (Plane)SmallRunway[0];
                SmallRunway.Remove(nxtPlane);
            }
            else
            {
                Console.WriteLine("Incorrect runway size. Must be: 'small' or 'large'");
                nxtPlane = null;
            }

            return nxtPlane;
        }
        public string GetSchedule()
        {
            string schedule = "";
            schedule += "Planes departing on the Large Runway:";
            foreach (Plane item in LargeRunway)
            {
                schedule = schedule + "\nPlane id:" + item.Id + "Type:" + item.Type;
            }
            schedule += "\n---------------------------------------------";

            schedule += "\nPlanes departing on the Small Runway:";
            foreach (Plane item in SmallRunway)
            {
                schedule = schedule + "\nPlane id:" + item.Id + "Type:" + item.Type;
            }
            schedule += "\n---------------------------------------------";

            return schedule;
        }

    }
    
}
