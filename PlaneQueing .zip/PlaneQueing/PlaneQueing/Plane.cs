﻿namespace PlaneQueing
{
    public class Plane
    {
        /* Id is reprented by a number while the size and type
         * are in string format.*/
        public int Id { get; set; }
        public string Size { get; set; }
        public string Type { get; set; }


        /*This class is able to represent the 4 diffrent plane objects*/
        public Plane(int id, string size, string type)
        {
            Id = id;
            Size = size.ToLower();
            Type = type.ToLower();

        }

    }
}
