﻿using Newtonsoft.Json.Linq;
using System;
using System.IO;

namespace PlaneQueing
{
    partial class Program
    {
        static void Main(string[] args)
        {
            /* The airport program contains 2 classes. One class contains the airport details while 
             * there is a seprate class for a plane object
             * The airport class handles the queuing of planes, handling the NextPlane method and retireving 
             * the airport schedule. More details are on their respective classes. 
             */

            /*below is an example of how to populate the airport and use it's methods*/
            var airport = new Airport();

            /* this code snippet is to load plane object through json file if needed
             *string res = File.ReadAllText("planes.json");
            
             *var planes = JArray.Parse(res);

             *for (int i = 0; i < planes.Count; i++)
             *{
             *   var id = Int32.Parse(planes[i]["id"].ToString());
             *   var sz = planes[i]["size"].ToString();
             *   var tp = planes[i]["type"].ToString();
             *   airport.AddToSchedule(new Plane(id, sz, tp));
             *}
             */

	    //For display purposes I used the format below
            airport.AddToSchedule(new Plane(11, "small", "cargo"));
            airport.AddToSchedule(new Plane(3, "large", "passenger"));
            airport.AddToSchedule(new Plane(2, "large", "cargo"));
            airport.AddToSchedule(new Plane(5, "small", "passenger"));
            airport.AddToSchedule(new Plane(66, "large", "cargo"));
            airport.AddToSchedule(new Plane(97, "small", "passenger"));

            Console.WriteLine(airport.GetSchedule());
            airport.NextPlane("small");
            airport.NextPlane("large");


        }
    }
}
